package at.dataflow.targets;

public class ZeroAnalysis3 {
    public static int func(int m, int n) {
        int x = 0;
        int j = m / n;
        return j;
    }
}
