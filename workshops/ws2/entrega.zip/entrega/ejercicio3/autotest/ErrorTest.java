package org.autotest;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ ErrorTest0.class, ErrorTest1.class, ErrorTest2.class, ErrorTest3.class, ErrorTest4.class, ErrorTest5.class, ErrorTest6.class })
public class ErrorTest {
}

